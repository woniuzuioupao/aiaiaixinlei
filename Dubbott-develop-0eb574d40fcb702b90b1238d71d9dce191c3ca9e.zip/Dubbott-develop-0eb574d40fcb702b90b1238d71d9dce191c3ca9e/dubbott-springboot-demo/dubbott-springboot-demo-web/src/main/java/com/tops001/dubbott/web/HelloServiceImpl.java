/*
 * ******************************************************************************
 *  * Copyright (c) 2016 Tops Tech Corp.
 *  *
 *  *
 *  * This software is the confidential and proprietary information of
 *  * Tops Tech Company. ("Confidential Information").  You shall not
 *  * disclose such Confidential Information and shall use it only in
 *  * accordance with the terms of the license agreement you entered into
 *  * with tops001.com.
 *  * ******************************************************************************
 */

package com.tops001.dubbott.web;

import com.tops001.dubbott.api.User;
import com.tops001.dubbott.web.api.HelloService;
import org.springframework.stereotype.Service;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import java.util.HashMap;
import java.util.Map;

/**
 * @author nealhu
 *
 */
@Path("/hello")
@Service
public class HelloServiceImpl implements HelloService {

    private Map<Long, User> users = new HashMap<Long, User>();

    public User getUser(Long id/* , @Context HttpServletRequest request */) {
        return users.get(id);
    }

    public User registerUser(User user) {
        users.put(user.getId(), user);
        return user;
    }


    @GET
    @Path("/{name}/{age}/")
    @Override
    public String hello(@PathParam("name") String name, @PathParam("age") String age) {
        return name + age;
    }

}

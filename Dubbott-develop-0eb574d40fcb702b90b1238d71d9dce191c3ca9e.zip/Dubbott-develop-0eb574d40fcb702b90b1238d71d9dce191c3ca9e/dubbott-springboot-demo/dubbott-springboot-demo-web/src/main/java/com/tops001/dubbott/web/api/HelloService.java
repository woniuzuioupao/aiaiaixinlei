/*
 * ******************************************************************************
 *  * Copyright (c) 2016 Tops Tech Corp.
 *  *
 *  *
 *  * This software is the confidential and proprietary information of
 *  * Tops Tech Company. ("Confidential Information").  You shall not
 *  * disclose such Confidential Information and shall use it only in
 *  * accordance with the terms of the license agreement you entered into
 *  * with tops001.com.
 *  * ******************************************************************************
 */

package com.tops001.dubbott.web.api;

import com.tops001.dubbott.api.User;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import javax.validation.constraints.Min;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

/**
 * @author nealhu
 *
 */
@Path("/hello")
@Api(tags = "HelloService", description = "Hello api")
public interface HelloService {

    @GET
    @Path("/{name}/{age}/")
    @ApiOperation(value = "hello", notes = "")
    public String hello(@PathParam("name") String name, @PathParam("age") String age);

    @GET
    @Path("{id : \\d+}")
    @ApiOperation(value = "获取用户对象", notes = "")
    User getUser(@PathParam(value = "id") @Min(value=1L, message="User ID must be greater than 1") Long id/*, HttpServletRequest request*/);

    @POST
    @Path("register")
    @ApiOperation(value = "注册用户",  notes = "")
    User registerUser(User user);

}

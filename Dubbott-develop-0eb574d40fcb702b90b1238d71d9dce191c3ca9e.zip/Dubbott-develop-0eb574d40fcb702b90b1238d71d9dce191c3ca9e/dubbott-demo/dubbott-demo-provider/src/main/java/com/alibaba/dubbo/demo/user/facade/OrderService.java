package com.alibaba.dubbo.demo.user.facade;

public interface OrderService {

    String getOrder(long orderId);

}

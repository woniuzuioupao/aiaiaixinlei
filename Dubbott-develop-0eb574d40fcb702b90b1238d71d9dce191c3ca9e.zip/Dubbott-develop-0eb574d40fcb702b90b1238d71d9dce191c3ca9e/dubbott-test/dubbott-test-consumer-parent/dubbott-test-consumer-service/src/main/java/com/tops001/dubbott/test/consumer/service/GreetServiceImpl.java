package com.tops001.dubbott.test.consumer.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.tops001.dubbott.test.consumer.api.GreetDTO;
import com.tops001.dubbott.test.consumer.api.GreetService;

@Service
public class GreetServiceImpl implements GreetService {

	@Override
	public String welcome(String username) {
		return "Hello " + username + "!";
	}

	@Override
	public List<GreetDTO> list(String username) {
		List<GreetDTO> result = new ArrayList<GreetDTO>();
		result.add(new GreetDTO(123L, "lz", new Date(), "abc"));
		result.add(new GreetDTO(567L, "lz", new Date(), "xyz"));
		return result;
	}

}

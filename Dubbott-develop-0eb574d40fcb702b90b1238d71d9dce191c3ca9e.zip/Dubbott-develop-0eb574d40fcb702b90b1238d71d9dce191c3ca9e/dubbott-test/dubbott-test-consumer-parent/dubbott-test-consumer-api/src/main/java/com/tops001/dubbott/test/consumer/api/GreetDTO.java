package com.tops001.dubbott.test.consumer.api;

import java.io.Serializable;
import java.util.Date;

public class GreetDTO implements Serializable {
	private static final long serialVersionUID = -2685783105413662081L;

	private Long id;
	private String name;
	private Date gmtCreate;

	public GreetDTO() {
	}

	public GreetDTO(Long id, String name, Date gmtCreate) {
		this.id = id;
		this.name = name;
		this.gmtCreate = gmtCreate;
	}

	public GreetDTO(Long id, String name, Date gmtCreate, String city) {
		super();
		this.id = id;
		this.name = name;
		this.gmtCreate = gmtCreate;
		this.city = city;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getGmtCreate() {
		return gmtCreate;
	}

	public void setGmtCreate(Date gmtCreate) {
		this.gmtCreate = gmtCreate;
	}

	private String city;
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "GreetDTO [id=" + id + ", name=" + name + ", gmtCreate=" + gmtCreate + "]";
	}
}

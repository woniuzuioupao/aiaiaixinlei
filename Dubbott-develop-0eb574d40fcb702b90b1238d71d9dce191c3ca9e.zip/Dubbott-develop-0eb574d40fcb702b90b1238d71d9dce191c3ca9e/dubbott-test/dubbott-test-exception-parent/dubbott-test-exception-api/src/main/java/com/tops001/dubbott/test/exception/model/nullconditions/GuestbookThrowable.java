package com.tops001.dubbott.test.exception.model.nullconditions;

public class GuestbookThrowable extends Throwable {

    private static final long serialVersionUID = 1L;

}

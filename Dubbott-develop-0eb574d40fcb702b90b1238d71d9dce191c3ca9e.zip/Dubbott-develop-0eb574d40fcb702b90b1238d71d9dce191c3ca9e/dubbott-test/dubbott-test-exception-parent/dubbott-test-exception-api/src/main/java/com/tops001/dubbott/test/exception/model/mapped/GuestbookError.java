package com.tops001.dubbott.test.exception.model.mapped;

public class GuestbookError extends Error {

    private static final long serialVersionUID = -1247655313421068853L;

    public GuestbookError(String message) {
        super(message);
    }
}

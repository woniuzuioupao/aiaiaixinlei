/*******************************************************************************
 * Copyright (c) 2016 Tops Tech Corp.
 *
 *
 * This software is the confidential and proprietary information of
 * Tops Tech Company. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with tops001.com. 
 * *******************************************************************************/
package com.tops001.dubbott.rpc.protocol.rest.cxf;

/**
 * @author nealhu on Jun 30, 2016 3:23:35 AM
 */
public class CXFRestConstants {

    public static final String CONTEXT_PATH    = "com.tops001.dubbott.contextpath";
    public static final String DUBBOTT_URL     = "com.tops001.dubbott.url";
    public static final String OWNER_KEY       = "owner";
    public static final int    DEFAULT_TIMEOUT = 5000;
    public static final String DUBBOTT_ALLOWORIGINS = "com.tops001.dubbott.cors.alloworigins";
    public static final String DUBBOTT_JACKSON_WRITE_NULL_MAP_VALUES = "com.tops001.dubbott.jackson.writenullmap";
    public static final String DUBBOTT_JACKSON_FAIL_ON_UNKNOWN_PROPERTIES = "com.tops001.dubbott.jackson.failonunknown";
    public static final String DUBBOTT_JACKSON_NON_NULL = "com.tops001.dubbott.jackson.nonnull";
    public static final String DUBBOTT_JACKSON_CASE_INSENSITIVE = "com.tops001.dubbott.jackson.caseinsensitive";
    //add serlvet mapping static resource list support
    public static final String DUBBOTT_CXF_SERVLET_STATIC_LIST = "com.tops001.dubbott.cxf.serevlet.staticresourceslist";
    public static final String DUBBOTT_CXF_SERVLET_STATIC_LIST_NAME = "static-resources-list";
    public static final String DUBBOTT_CXF_SERVLET_WELCOME_FILE = "com.tops001.dubbott.cxf.serevlet.staticwelcomefile";
    public static final String DUBBOTT_CXF_SERVLET_WELCOME_FILE_NAME = "static-welcome-file";

}

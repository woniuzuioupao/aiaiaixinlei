/*
 * ******************************************************************************
 *  * Copyright (c) 2016 Tops Tech Corp.
 *  *
 *  *
 *  * This software is the confidential and proprietary information of
 *  * Tops Tech Company. ("Confidential Information").  You shall not
 *  * disclose such Confidential Information and shall use it only in
 *  * accordance with the terms of the license agreement you entered into
 *  * with tops001.com.
 *  * ******************************************************************************
 */

package com.tops001.dubbott.rpc.protocol.rest.cxf.utils;

import javax.servlet.ServletContext;

/**
 * Created by nealhu on 2017/6/19.
 */
public class ServletUtils {

    public static String getFromServletContext(ServletContext context, String key) {
        String value = context.getInitParameter(key);
        if (value == null || value.isEmpty()) {
            value = (String) context.getAttribute(key);
        }
        return value;
    }
}

/*******************************************************************************
 * Copyright (c) 2016 Tops Tech Corp.
 *
 *
 * This software is the confidential and proprietary information of
 * Tops Tech Company. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with tops001.com. 
 * *******************************************************************************/
package com.tops001.dubbott.rpc.protocol.rest.cxf;

import java.lang.reflect.Field;
import java.util.Map;

import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.ClassUtils;
import org.springframework.util.ReflectionUtils;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;


/**
 * @author LiZhe on Jul 6, 2017 20:20:09 PM
 */
public class JacksonJsonProviderFactoryBean implements FactoryBean<JacksonJaxbJsonProvider>, InitializingBean {

	private JacksonJaxbJsonProvider provider;
	
	private ObjectMapper objectMapper;

	private Map<String, Boolean> features;

	@Override
	public void afterPropertiesSet() throws Exception {
		provider = new JacksonJaxbJsonProvider();
		for (Map.Entry<String, Boolean> entry : this.features.entrySet()) {
			configureFeature(this.parse(entry.getKey()), entry.getValue());
		}
		
		//this.objectMapper.setSerializationInclusion(null);
		provider.setMapper(this.objectMapper);
		
	}

	public Object parse(String key) throws ClassNotFoundException, NoSuchFieldException, IllegalArgumentException, IllegalAccessException {
		int lastDotIndex = key.lastIndexOf('.');
		if (lastDotIndex == -1 || lastDotIndex == key.length()) {
			throw new IllegalArgumentException(" field name format error: "
					+ "e.g. 'example.MyExampleClass.MY_EXAMPLE_FIELD'");
		}
		String className = key.substring(0, lastDotIndex);
		String fieldName = key.substring(lastDotIndex + 1);
		Class<?> targetClass = ClassUtils.forName(className, ClassUtils.getDefaultClassLoader());
		Field fieldObject = targetClass.getField(fieldName);
		ReflectionUtils.makeAccessible(fieldObject);
		return fieldObject.get(null);
	}

	private void configureFeature(Object feature, boolean enabled) {
		if (feature instanceof JsonParser.Feature) {
			this.objectMapper.configure((JsonParser.Feature) feature, enabled);
		} else if (feature instanceof JsonGenerator.Feature) {
			this.objectMapper.configure((JsonGenerator.Feature) feature, enabled);
		} else if (feature instanceof SerializationFeature) {
			this.objectMapper.configure((SerializationFeature) feature, enabled);
		} else if (feature instanceof DeserializationFeature) {
			this.objectMapper.configure((DeserializationFeature) feature, enabled);
		} else if (feature instanceof MapperFeature) {
			this.objectMapper.configure((MapperFeature) feature, enabled);
		} else {
			throw new FatalBeanException("Unknown feature class: " + feature.getClass().getName());
		}
	}

	@Override
	public JacksonJaxbJsonProvider getObject() throws Exception {
		return this.provider;
	}

	@Override
	public Class<?> getObjectType() {
		return JacksonJaxbJsonProvider.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}
	
	public void setObjectMapper(ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
	}
	
	public void setFeatures(Map<String, Boolean> features) {
		this.features = features;
	}


}

package com.tops001.dubbott.rpc.protocol.rest.cxf.utils;

import java.io.File;
/**
 * Created by nealhu on 2016/11/14.
 */


@SuppressWarnings("rawtypes")
public class RuntimeServerUtil {

    private static final String JBOSS_CLASS = "/org/jboss/Main.class";

    private static final String JETTY_CLASS = "/org/eclipse/jetty/server/Server.class";

    private static final String TOMCAT_CLASS = "/org/apache/catalina/startup/Bootstrap.class";

    private static final RuntimeServerUtil _instance = new RuntimeServerUtil();

    private volatile static String serverConfigPath;

    private final static  String separator = File.separator;

    private Boolean _jBoss;

    private Boolean _jetty;

    private Boolean _tomcat;

    private RuntimeServerUtil() {
    }

    public static boolean isJBoss() {
        RuntimeServerUtil sd = _instance;
        if (sd._jBoss == null) {
            Class c = sd.getClass();
            if (c.getResource(JBOSS_CLASS) != null) {
                sd._jBoss = Boolean.TRUE;
            } else {
                sd._jBoss = Boolean.FALSE;
            }
        }
        return sd._jBoss.booleanValue();
    }

    public static boolean isJetty() {
        RuntimeServerUtil sd = _instance;

        if (sd._jetty == null) {
            Class c = sd.getClass().getClassLoader().getClass();
            if (c.getResource(JETTY_CLASS) != null) {
                sd._jetty = Boolean.TRUE;
            } else {
                sd._jetty = Boolean.FALSE;
            }
        }
        return sd._jetty.booleanValue();
    }

    public static boolean isTomcat() {
        RuntimeServerUtil sd = _instance;

        if (sd._tomcat == null) {
            Class c = sd.getClass();
            if (c.getResource(TOMCAT_CLASS) != null) {
                sd._tomcat = Boolean.TRUE;
            } else {
                sd._tomcat = Boolean.FALSE;
            }
        }
        return sd._tomcat.booleanValue();
    }

    public static String getServerConfPath() {
        if (serverConfigPath != null) {
            return serverConfigPath;
        }

        StringBuilder buf = null;
        if (isJBoss()) {
            String jbossHome = System.getenv("JBOSS_HOME");
            if (jbossHome == null) {
                jbossHome = System.getProperty("jboss.home.dir");
            }
            buf = new StringBuilder();
            buf.append(jbossHome).append(separator);
            buf.append("server").append(separator);
            buf.append("default").append(separator);
            buf.append("conf").append(separator);
        } else if (isTomcat()) {
            String catalinaHome = System.getenv("CATALINA_HOME");
            if (catalinaHome == null) {
                catalinaHome = System.getProperty("catalina.home");
            }
            buf = new StringBuilder();
            buf.append(catalinaHome).append(separator);
            buf.append("conf").append(separator);
        }

        if (buf != null) {
            serverConfigPath = buf.toString();
        }

        return serverConfigPath;
    }

}

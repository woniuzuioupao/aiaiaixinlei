/**
 * 
 */
package com.tops001.dubbott.rpc.filter;

import java.util.Map;

import com.alibaba.dubbo.common.Constants;
import com.alibaba.dubbo.common.extension.Activate;
import com.alibaba.dubbo.rpc.Filter;
import com.alibaba.dubbo.rpc.Invocation;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.Result;
import com.alibaba.dubbo.rpc.RpcException;

/**
 * @author lizhe
 * 
 * Dubbo RPC异步方式调用问题修正
 * 由于Dubbo核心包异步调用调用bug，在A(异步)--->B(同步)--->C形式的调用链路，原本B同步去调用C，结果受A异步调B影响，变成了B异步方式调用C。
 * 移除下游系统异步调用传入的异步调用参数，避免影响到内部再次发起的服务调用
 */
@Activate(group = Constants.PROVIDER, order=-1000001)
public class RpcAsyncReviseFilter implements Filter {


	@Override
	public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        Map<String, String> attachments = invocation.getAttachments();
        if (attachments != null) {
            attachments.remove(Constants.ASYNC_KEY);
        }
    	return invoker.invoke(invocation);
	}

}

文档见
http://confluence.tech.apitops.com/pages/viewpage.action?pageId=3441264